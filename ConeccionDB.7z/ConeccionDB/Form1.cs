﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;
using System.Data.Common;

namespace ConeccionDB
{

    public partial class MainLogin : Form
    {
        public MainLogin()
        {
            InitializeComponent();

        }

        //Establecemos la conexio con la base de datos
        SqlConnection Conexion = new SqlConnection("server=B9-202-26882; database=DB_Biblioteca2023; integrated security=true");

        private void MainLogin_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dB_Biblioteca2023DataSet.tblusuario' Puede moverla o quitarla según sea necesario.
            
            //Cargamos la informacion del DataGridView"Panel_Datos"
            string Consulta = "select * from tblusuario";
            SqlDataAdapter adaptador = new SqlDataAdapter(Consulta, Conexion);
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            Panel_Datos.DataSource = dt;
            

        }

        public void editar_Tabla()
        {
            string Consulta = "select * from tblusuario";
            SqlDataAdapter adaptador2 = new SqlDataAdapter(Consulta, Conexion);
            DataTable dt = new DataTable();
            adaptador2.Fill(dt);
            Panel_Datos.DataSource = dt;
        }

        private void BtnCrear_Click(object sender, EventArgs e)
        {
            // Iniciamos la conexion y definimos las variables
            Conexion.Open();
            int Cedu = int.Parse(TxtId.Text);
            string Nombre = TxtNom.Text;
            int Telefono = int.Parse(TxtTel.Text);
            string Direccion = TxtDir.Text;
            int Cod_tipo = int.Parse(TxtTip_Cod.Text);
            string Estado = TxtEst.Text;

            //Se realiza la consulta
            string Consulta_Crear = ("insert into tblusuario values ("+TxtId.Text+", '"+TxtNom.Text+"', "+TxtTel.Text+", '"+TxtDir.Text+"', "+TxtTip_Cod.Text+", '"+TxtEst.Text+"')");
            SqlCommand Comando = new SqlCommand(Consulta_Crear,Conexion);
            SqlDataReader C = Comando.ExecuteReader();
            MessageBox.Show ("Registro agregado");
            Conexion.Close();
            editar_Tabla();
        }

        private void BtnElimi_Click(object sender, EventArgs e)
        {
            // Iniciamos la conexion y definimos las variables
            Conexion.Open();
            int Cedu = int.Parse(TxtId.Text);

            //Realizamos la consulta para eliminar  los registros. Haciendo uso del id(txtId) 
            string Consulta_Eliminar = "delete from tblusuario where Cedula= "+TxtId.Text+"";
            SqlCommand Comando = new SqlCommand(Consulta_Eliminar, Conexion);
            SqlDataReader E = Comando.ExecuteReader();
            MessageBox.Show("Registro Eliminado");
            Conexion.Close();
            editar_Tabla();

        }

        private void btnAct_Click(object sender, EventArgs e)
        {
            // Iniciamos la conexion y definimos las variables
            Conexion.Open();
            int Cedu = int.Parse(TxtId.Text);

            //Realizamos la consulta para actualizar los registros. Haciendo uso del id(txtId) 
            string Consulta_Buscar = "update tblusuario set Cedula= "+TxtId.Text+ ", Nombre= '"+TxtNom.Text+"', Tel= "+TxtTel.Text+", Dir= '"+TxtDir.Text+"', Cod_Tipo= "+TxtTip_Cod.Text+", Estado= '"+TxtEst.Text+"' where Cedula= "+TxtId.Text+"";
            SqlCommand Comando = new SqlCommand(Consulta_Buscar, Conexion);
            SqlDataReader E = Comando.ExecuteReader();
            MessageBox.Show("Registro Encontrado");
            Conexion.Close();
            editar_Tabla();
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            // Iniciamos la conexion y definimos las variables
            Conexion.Open();
            int Cedu = int.Parse(TxtId.Text);

            //Realizamos la consulta para buscar  los registros. Haciendo uso del id(txtId) 
            string Consulta_Buscar = "select * from tblusuario where Cedula= "+TxtId.Text+"";
            SqlDataAdapter adaptador3= new SqlDataAdapter(Consulta_Buscar, Conexion);
            DataTable dt = new DataTable();
            adaptador3.Fill(dt);
            Panel_Datos.DataSource = dt;
        }

             

        private void Panel_Datos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
                
        }

        private void Panel_Datos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            TxtId.Text = Panel_Datos.SelectedCells[0].Value.ToString();
            TxtNom.Text = Panel_Datos.SelectedCells[1].Value.ToString();
            TxtTel.Text = Panel_Datos.SelectedCells[2].Value.ToString();
            TxtDir.Text = Panel_Datos.SelectedCells[3].Value.ToString();
            TxtTip_Cod.Text = Panel_Datos.SelectedCells[4].Value.ToString();
            TxtEst.Text = Panel_Datos.SelectedCells[5].Value.ToString();
        }

        
    }
}
