﻿namespace ConeccionDB
{
    partial class MainLogin
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblNombre = new System.Windows.Forms.Label();
            this.LblEst = new System.Windows.Forms.Label();
            this.TxtNom = new System.Windows.Forms.TextBox();
            this.TxtEst = new System.Windows.Forms.TextBox();
            this.BtnCrear = new System.Windows.Forms.Button();
            this.BtnBuscar = new System.Windows.Forms.Button();
            this.BtnElimi = new System.Windows.Forms.Button();
            this.btnAct = new System.Windows.Forms.Button();
            this.LblId = new System.Windows.Forms.Label();
            this.TxtId = new System.Windows.Forms.TextBox();
            this.TxtDir = new System.Windows.Forms.TextBox();
            this.TxtTel = new System.Windows.Forms.TextBox();
            this.LblDir = new System.Windows.Forms.Label();
            this.LblTel = new System.Windows.Forms.Label();
            this.llblCod = new System.Windows.Forms.Label();
            this.TxtTip_Cod = new System.Windows.Forms.TextBox();
            this.dB_Biblioteca2023DataSet = new ConeccionDB.DB_Biblioteca2023DataSet();
            this.dBBiblioteca2023DataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Panel_Datos = new System.Windows.Forms.DataGridView();
            this.Cedula = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Dir = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cod_Tipo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cedulaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dirDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codTipoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estadoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblusuarioTableAdapter = new ConeccionDB.DB_Biblioteca2023DataSetTableAdapters.tblusuarioTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dB_Biblioteca2023DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBBiblioteca2023DataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Panel_Datos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(24, 81);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(142, 20);
            this.lblNombre.TabIndex = 0;
            this.lblNombre.Text = "Ingrese su nombre";
            // 
            // LblEst
            // 
            this.LblEst.AutoSize = true;
            this.LblEst.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblEst.Location = new System.Drawing.Point(24, 126);
            this.LblEst.Name = "LblEst";
            this.LblEst.Size = new System.Drawing.Size(137, 20);
            this.LblEst.TabIndex = 1;
            this.LblEst.Text = "Ingrese su estado";
            // 
            // TxtNom
            // 
            this.TxtNom.Location = new System.Drawing.Point(191, 81);
            this.TxtNom.Name = "TxtNom";
            this.TxtNom.Size = new System.Drawing.Size(100, 20);
            this.TxtNom.TabIndex = 2;
            // 
            // TxtEst
            // 
            this.TxtEst.Location = new System.Drawing.Point(191, 128);
            this.TxtEst.Name = "TxtEst";
            this.TxtEst.Size = new System.Drawing.Size(100, 20);
            this.TxtEst.TabIndex = 3;
            // 
            // BtnCrear
            // 
            this.BtnCrear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCrear.Location = new System.Drawing.Point(41, 325);
            this.BtnCrear.Name = "BtnCrear";
            this.BtnCrear.Size = new System.Drawing.Size(125, 50);
            this.BtnCrear.TabIndex = 4;
            this.BtnCrear.Text = "Crear usuario";
            this.BtnCrear.UseVisualStyleBackColor = true;
            this.BtnCrear.Click += new System.EventHandler(this.BtnCrear_Click);
            // 
            // BtnBuscar
            // 
            this.BtnBuscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnBuscar.Location = new System.Drawing.Point(41, 177);
            this.BtnBuscar.Name = "BtnBuscar";
            this.BtnBuscar.Size = new System.Drawing.Size(125, 50);
            this.BtnBuscar.TabIndex = 5;
            this.BtnBuscar.Text = "Buscar usuario";
            this.BtnBuscar.UseVisualStyleBackColor = true;
            this.BtnBuscar.Click += new System.EventHandler(this.BtnBuscar_Click);
            // 
            // BtnElimi
            // 
            this.BtnElimi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnElimi.Location = new System.Drawing.Point(41, 388);
            this.BtnElimi.Name = "BtnElimi";
            this.BtnElimi.Size = new System.Drawing.Size(125, 50);
            this.BtnElimi.TabIndex = 6;
            this.BtnElimi.Text = "Eliminar";
            this.BtnElimi.UseVisualStyleBackColor = true;
            this.BtnElimi.Click += new System.EventHandler(this.BtnElimi_Click);
            // 
            // btnAct
            // 
            this.btnAct.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAct.Location = new System.Drawing.Point(41, 254);
            this.btnAct.Name = "btnAct";
            this.btnAct.Size = new System.Drawing.Size(125, 50);
            this.btnAct.TabIndex = 7;
            this.btnAct.Text = "Actualizar";
            this.btnAct.UseVisualStyleBackColor = true;
            this.btnAct.Click += new System.EventHandler(this.btnAct_Click);
            // 
            // LblId
            // 
            this.LblId.AutoSize = true;
            this.LblId.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblId.Location = new System.Drawing.Point(24, 36);
            this.LblId.Name = "LblId";
            this.LblId.Size = new System.Drawing.Size(102, 20);
            this.LblId.TabIndex = 1;
            this.LblId.Text = "Ingrese su Id";
            // 
            // TxtId
            // 
            this.TxtId.Location = new System.Drawing.Point(191, 38);
            this.TxtId.Name = "TxtId";
            this.TxtId.Size = new System.Drawing.Size(100, 20);
            this.TxtId.TabIndex = 9;
            // 
            // TxtDir
            // 
            this.TxtDir.Location = new System.Drawing.Point(548, 81);
            this.TxtDir.Name = "TxtDir";
            this.TxtDir.Size = new System.Drawing.Size(100, 20);
            this.TxtDir.TabIndex = 10;
            // 
            // TxtTel
            // 
            this.TxtTel.Location = new System.Drawing.Point(548, 128);
            this.TxtTel.Name = "TxtTel";
            this.TxtTel.Size = new System.Drawing.Size(100, 20);
            this.TxtTel.TabIndex = 11;
            // 
            // LblDir
            // 
            this.LblDir.AutoSize = true;
            this.LblDir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDir.Location = new System.Drawing.Point(355, 81);
            this.LblDir.Name = "LblDir";
            this.LblDir.Size = new System.Drawing.Size(151, 20);
            this.LblDir.TabIndex = 12;
            this.LblDir.Text = "Ingrese su direccion";
            // 
            // LblTel
            // 
            this.LblTel.AutoSize = true;
            this.LblTel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTel.Location = new System.Drawing.Point(355, 128);
            this.LblTel.Name = "LblTel";
            this.LblTel.Size = new System.Drawing.Size(146, 20);
            this.LblTel.TabIndex = 13;
            this.LblTel.Text = "Ingrese su telefono";
            // 
            // llblCod
            // 
            this.llblCod.AutoSize = true;
            this.llblCod.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llblCod.Location = new System.Drawing.Point(348, 36);
            this.llblCod.Name = "llblCod";
            this.llblCod.Size = new System.Drawing.Size(187, 20);
            this.llblCod.TabIndex = 14;
            this.llblCod.Text = "Ingrese su tipo de codigo";
            // 
            // TxtTip_Cod
            // 
            this.TxtTip_Cod.Location = new System.Drawing.Point(548, 36);
            this.TxtTip_Cod.Name = "TxtTip_Cod";
            this.TxtTip_Cod.Size = new System.Drawing.Size(100, 20);
            this.TxtTip_Cod.TabIndex = 15;
            // 
            // dB_Biblioteca2023DataSet
            // 
            this.dB_Biblioteca2023DataSet.DataSetName = "DB_Biblioteca2023DataSet";
            this.dB_Biblioteca2023DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dBBiblioteca2023DataSetBindingSource
            // 
            this.dBBiblioteca2023DataSetBindingSource.DataMember = "tblusuario";
            this.dBBiblioteca2023DataSetBindingSource.DataSource = this.dB_Biblioteca2023DataSet;
            // 
            // Panel_Datos
            // 
            this.Panel_Datos.AllowUserToOrderColumns = true;
            this.Panel_Datos.AutoGenerateColumns = false;
            this.Panel_Datos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Panel_Datos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Cedula,
            this.Nombre,
            this.Tel,
            this.Dir,
            this.Cod_Tipo,
            this.estado,
            this.cedulaDataGridViewTextBoxColumn,
            this.nombreDataGridViewTextBoxColumn,
            this.telDataGridViewTextBoxColumn,
            this.dirDataGridViewTextBoxColumn,
            this.codTipoDataGridViewTextBoxColumn,
            this.estadoDataGridViewTextBoxColumn});
            this.Panel_Datos.DataSource = this.dBBiblioteca2023DataSetBindingSource;
            this.Panel_Datos.Location = new System.Drawing.Point(352, 146);
            this.Panel_Datos.Name = "Panel_Datos";
            this.Panel_Datos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Panel_Datos.Size = new System.Drawing.Size(645, 292);
            this.Panel_Datos.TabIndex = 17;
            this.Panel_Datos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Panel_Datos_CellClick);
            this.Panel_Datos.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Panel_Datos_CellContentClick);
            // 
            // Cedula
            // 
            this.Cedula.DataPropertyName = "Cedula";
            this.Cedula.Frozen = true;
            this.Cedula.HeaderText = "Id";
            this.Cedula.Name = "Cedula";
            this.Cedula.ReadOnly = true;
            // 
            // Nombre
            // 
            this.Nombre.DataPropertyName = "Nombre";
            this.Nombre.Frozen = true;
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.Name = "Nombre";
            this.Nombre.ReadOnly = true;
            // 
            // Tel
            // 
            this.Tel.DataPropertyName = "Tel";
            this.Tel.Frozen = true;
            this.Tel.HeaderText = "telefono";
            this.Tel.Name = "Tel";
            this.Tel.ReadOnly = true;
            // 
            // Dir
            // 
            this.Dir.DataPropertyName = "Dir";
            this.Dir.Frozen = true;
            this.Dir.HeaderText = "Direccion";
            this.Dir.Name = "Dir";
            this.Dir.ReadOnly = true;
            // 
            // Cod_Tipo
            // 
            this.Cod_Tipo.DataPropertyName = "Cod_Tipo";
            this.Cod_Tipo.Frozen = true;
            this.Cod_Tipo.HeaderText = "Cod_Tipo";
            this.Cod_Tipo.Name = "Cod_Tipo";
            this.Cod_Tipo.ReadOnly = true;
            // 
            // estado
            // 
            this.estado.DataPropertyName = "Estado";
            this.estado.Frozen = true;
            this.estado.HeaderText = "Estado";
            this.estado.Name = "estado";
            this.estado.ReadOnly = true;
            // 
            // cedulaDataGridViewTextBoxColumn
            // 
            this.cedulaDataGridViewTextBoxColumn.DataPropertyName = "Cedula";
            this.cedulaDataGridViewTextBoxColumn.HeaderText = "Cedula";
            this.cedulaDataGridViewTextBoxColumn.Name = "cedulaDataGridViewTextBoxColumn";
            // 
            // nombreDataGridViewTextBoxColumn
            // 
            this.nombreDataGridViewTextBoxColumn.DataPropertyName = "Nombre";
            this.nombreDataGridViewTextBoxColumn.HeaderText = "Nombre";
            this.nombreDataGridViewTextBoxColumn.Name = "nombreDataGridViewTextBoxColumn";
            // 
            // telDataGridViewTextBoxColumn
            // 
            this.telDataGridViewTextBoxColumn.DataPropertyName = "tel";
            this.telDataGridViewTextBoxColumn.HeaderText = "tel";
            this.telDataGridViewTextBoxColumn.Name = "telDataGridViewTextBoxColumn";
            // 
            // dirDataGridViewTextBoxColumn
            // 
            this.dirDataGridViewTextBoxColumn.DataPropertyName = "Dir";
            this.dirDataGridViewTextBoxColumn.HeaderText = "Dir";
            this.dirDataGridViewTextBoxColumn.Name = "dirDataGridViewTextBoxColumn";
            // 
            // codTipoDataGridViewTextBoxColumn
            // 
            this.codTipoDataGridViewTextBoxColumn.DataPropertyName = "Cod_Tipo";
            this.codTipoDataGridViewTextBoxColumn.HeaderText = "Cod_Tipo";
            this.codTipoDataGridViewTextBoxColumn.Name = "codTipoDataGridViewTextBoxColumn";
            // 
            // estadoDataGridViewTextBoxColumn
            // 
            this.estadoDataGridViewTextBoxColumn.DataPropertyName = "Estado";
            this.estadoDataGridViewTextBoxColumn.HeaderText = "Estado";
            this.estadoDataGridViewTextBoxColumn.Name = "estadoDataGridViewTextBoxColumn";
            // 
            // tblusuarioTableAdapter
            // 
            this.tblusuarioTableAdapter.ClearBeforeFill = true;
            // 
            // MainLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1245, 450);
            this.Controls.Add(this.Panel_Datos);
            this.Controls.Add(this.TxtTip_Cod);
            this.Controls.Add(this.llblCod);
            this.Controls.Add(this.LblTel);
            this.Controls.Add(this.LblDir);
            this.Controls.Add(this.TxtTel);
            this.Controls.Add(this.TxtDir);
            this.Controls.Add(this.TxtId);
            this.Controls.Add(this.LblId);
            this.Controls.Add(this.btnAct);
            this.Controls.Add(this.BtnElimi);
            this.Controls.Add(this.BtnBuscar);
            this.Controls.Add(this.BtnCrear);
            this.Controls.Add(this.TxtEst);
            this.Controls.Add(this.TxtNom);
            this.Controls.Add(this.LblEst);
            this.Controls.Add(this.lblNombre);
            this.Name = "MainLogin";
            this.Text = "Registros";
            this.Load += new System.EventHandler(this.MainLogin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dB_Biblioteca2023DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBBiblioteca2023DataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Panel_Datos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label LblEst;
        private System.Windows.Forms.TextBox TxtNom;
        private System.Windows.Forms.TextBox TxtEst;
        private System.Windows.Forms.Button BtnCrear;
        private System.Windows.Forms.Button BtnBuscar;
        private System.Windows.Forms.Button BtnElimi;
        private System.Windows.Forms.Button btnAct;
        private System.Windows.Forms.Label LblId;
        private System.Windows.Forms.TextBox TxtId;
        private System.Windows.Forms.TextBox TxtDir;
        private System.Windows.Forms.TextBox TxtTel;
        private System.Windows.Forms.Label LblDir;
        private System.Windows.Forms.Label LblTel;
        private System.Windows.Forms.Label llblCod;
        private System.Windows.Forms.TextBox TxtTip_Cod;
        private DB_Biblioteca2023DataSet dB_Biblioteca2023DataSet;
        private System.Windows.Forms.DataGridView Panel_Datos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cedula;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tel;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dir;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cod_Tipo;
        private System.Windows.Forms.DataGridViewTextBoxColumn estado;
        private System.Windows.Forms.DataGridViewTextBoxColumn cedulaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dirDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn codTipoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn estadoDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource dBBiblioteca2023DataSetBindingSource;
        private DB_Biblioteca2023DataSetTableAdapters.tblusuarioTableAdapter tblusuarioTableAdapter;
    }
}

